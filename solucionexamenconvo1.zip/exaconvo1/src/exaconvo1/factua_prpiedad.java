package exaconvo1;

public class factua_prpiedad {
	float precio;
	int cant;
	String nombre_product;
	
	
	public void calculos() {
		// TODO Auto-generated method stub
		
	}
	public void resultado() {
		// TODO Auto-generated method stub
		
	}
	
}
