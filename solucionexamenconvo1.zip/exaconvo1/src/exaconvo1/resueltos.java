package exaconvo1;

import java.util.Scanner;

public class resueltos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char op;
		boolean res=true;
		Scanner tc= new Scanner(System.in);
		
		while(res==true) {
			
			System.out.println("Ingrese una opcion\n a).eje1 b).eje2 c). eje3 d). eje4 e).eje5");
			op=tc.next().charAt(0);
			switch(op) {
			case 'a':
				System.out.println("ha ingresado al primer ejercicio\n");
				
				int f,c, matriz[][],datos, o=0;
				int suma=0, multi=0, formula=0, formula2=0;
				System.out.println("ingrese el numero de filas");
				f=tc.nextInt();

				System.out.println("ingrese el numero de columnas");
				c=tc.nextInt();
				
				matriz=new int [f][c];
				for(int i=0; i<f; i++) {
					for(int j=0; j<c; j++) {
						System.out.println("ingrese elemntos (f"+(i+1)+",c"+(j+1)+"):");
						datos=tc.nextInt();
						matriz[i][j]=datos;
						 
					}
				}
				
				
				for(int i=0; i<f; i++) {
					
					for(int j=0; j<c; j++) {
						System.out.print("[ "+matriz[i][j]+" ]");
						 
						 
						 
					}
					System.out.println("");
				}
				 
				System.out.println("\n resultado del producto punto");
				 
				 
				break;
				
			
				
				
			case 'b':
				System.out.println("** ha ingresado al tercer ejercicio\n");
				 int i1,j1,aux, filam=2, n=2; //3
					//int A[][]= {{4,1},{4,6}};
					char A[][]= {{'a','b'},{'c','d'}};
					char B[][]= {{'c','d'},{'a','b'}};
					
					if(n%2!=0) {
						filam=(n/2)-1;  //3
						//filam=1;
					}
					else {
						filam=(n/2);
					}
					System.out.println("normal");
					for( i1=0; i1<=filam; i1++) {
						for( j1=0; j1<n;j1++) {
						System.out.print(" "+A[i1][j1]);
						}
					System.out.println();
					}
					System.out.println();
					
					System.out.println("\n desorden");
					for( i1=0; i1<=filam; i1++) {
						for( j1=0; j1<n; j1++) {
							if((n%2!=0) && (i1==filam) && (j1==filam+1)) {
								
								break;}
								
							
							aux=A[i1][j1];
							A[i1][j1]=A[(n-1)-i1][(n-1)-j1];
							A[(n-1)-i1][(n-1)-j1]=(char) aux;
						}
						 
						for( j1=0; j1<n;j1++) {
							System.out.print(" "+A[i1][j1]);
						}
						System.out.println();
					 
					
					}
					System.out.println("\n Alrevez");
					for( i1=0; i1<=filam; i1++) {
						for( j1=0; j1<n;j1++) {
						System.out.print(" "+B[i1][j1]);
						}
					System.out.println();
					}
					System.out.println();
					
				
				
				break;
				
			case 'c':
				System.out.println("** ha ingresado al segundo ejercicio\n");
				factua_prpiedad fp= new factua_prpiedad();
				fp.calculos();
				fp.resultado();
				System.out.println("--------------------------------------------");
				
				System.out.printf("Nombre:  Detalle:   Total:\n");
				saltos();
				System.out.println("----------operaciones con calculos-------------------");
				
				break;
			
				
				
			case 'd':
				System.out.println("**ha ingresado al cuarto ejercicio\n");
				
				int lineas;
				System.out.println("ingres de cuantas lineas quiere su piramide");
				lineas=tc.nextInt();
				System.out.println();
				for(int h=1; h<=lineas; h++) {
					//espacio 
					for(int d=1; d<=lineas-h; d++) {
						System.out.print(" ");
					}
					//*
					for(int a=1; a<=(h*2)-1; a++) {
						System.out.print("*");
					}
					System.out.println();
				}
				 
				break;
				
			case 'e':
				System.out.println("**ha ingresado al quinto ejercicio Ordende matriz\n");
				int count, temp;

				System.out.println("Ingrese el tamaño de su vector");
				count=tc.nextInt();
				
				int num[]=new int[count];
				
				
				for(int i=0; i<count; i++) {
					System.out.println("ingrese elementos en posicion "+(i+1));
					num[i]=tc.nextInt();
					
				}
				 System.out.println("\n Datos ingresados:");
				 System.out.print("[");
				 for(int i=0; i<count; i++) {
					 
						System.out.print(""+num[i]+",");
						 
						
					}
				 System.out.println("]");
				 
				for(int k=0; k<count; k++) {
					for(int j2=k+1; j2<count; j2++) {
						if(num[k]>num[j2]) {
							temp=num[k];
							num[k]=num[j2];
							num[j2]=temp;
						}
						
					}
				}
					System.out.println("\n Orden menor a mayor:");
					
					for(int a=0; a<count-1; a++) {
						System.out.print(num[a]+",");
					}
					System.out.print(num[count-1]);
					 
					System.out.println();
					System.out.println("\n Orden mayor a menor:");
					for(int k=0; k<count; k++) {
						for(int j2=k+1; j2<count; j2++) {
							if(num[k]<num[j2]) {
								temp=num[k];
								num[k]=num[j2];
								num[j2]=temp;
							}
							
						}
					}
					System.out.print("{");
					for(int a=0; a<count-1; a++) {
						System.out.print(""+num[a]+",");
					}
					System.out.print(+num[count-1]+"}");
					
					 
				
				break;
			
			
			
				default:
					System.out.println("** Opcion invalida **");
					break;
			}
			
			saltos();
		}
		
		
		
	}
	
	public static void saltos() {
		for(int i=1; i<7; i++) {
			System.out.println();
		}
	}

}
